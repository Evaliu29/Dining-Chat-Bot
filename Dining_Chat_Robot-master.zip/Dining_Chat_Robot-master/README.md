# Dining_Chat_Robot
This is an Intelligent Dining chat Robot. It collect you basic information: city, dining time, wanted cuisine, phone number. Our system will recommend resturants from yelp dataset and send the restuarnt information to user via phone message.
&nbsp;
![image](https://github.com/ChenxiCui97/Dining_Chat_Robot/blob/master/images/cut1.PNG)
&nbsp;
![image](https://github.com/ChenxiCui97/Dining_Chat_Robot/blob/master/images/cut2.PNG)
&nbsp;
![image](https://github.com/ChenxiCui97/Dining_Chat_Robot/blob/master/images/cut3.jpg)
